var pingTimes = [];
    var notificationElement = document.getElementById("notification");

    function showNotification(message) {
      notificationElement.textContent = message;
      notificationElement.style.display = "block";
      setTimeout(function() {
        notificationElement.style.display = "none";
      }, 1000);
    }

    function checkServerLag() {
      var serverRequest = new XMLHttpRequest();
      var startTime = new Date().getTime();
      var serverURL = "https://example.com"; // Replace with your server URL

      serverRequest.onreadystatechange = function() {
        if (serverRequest.readyState === 4) {
          var endTime = new Date().getTime();
          var serverLatency = endTime - startTime;

          pingTimes.push(serverLatency);
          if (pingTimes.length > 1000) {
            pingTimes.shift(); // Remove oldest entry if more than 1000 entries
          }

          console.log("Server response time: " + serverLatency + "ms");

          var previousLatency = pingTimes[pingTimes.length - 2];
          var latencyDifference = serverLatency - previousLatency;

          if (latencyDifference > 100) {
            showNotification("Server lag detected.");
          } else {
            console.log("Server is responsive.");
          }
        }
      };

      serverRequest.open("GET", serverURL, true);
      serverRequest.send();
    

      pingRequest.open("HEAD", pingURL, true);
      pingRequest.send();
    }

    // Call the checkServerLag function every 5 seconds
    setInterval(checkServerLag, 5000);

showNotification("Client lag also detected.")