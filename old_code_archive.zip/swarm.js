var amount = 1
var recieverOfFeeds = "x"
function scriptifyDocument(doc){
        var htmlCode = `<!doctype html> \r\n<html lang=\"en\"> \r\n<head>\r\n






<link rel=\"icon\" href=\"myicon.ico\"\/>\r\n\t<meta charset=\"UTF-8\" \/>\r\n    <meta name='viewport' content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, minimal-ui\" \/>\r\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\r\n    <meta name=\"mobile-web-app-capable\" content=\"yes\">\r\n    <meta name=\"title\" content=\"Stomped.io\" \/>\r\n    <meta name=\"keywords\" content=\"stompedio, stomped, platformer, jumping, smash, io, game, games, web game, html5, fun, flash, multiplayer\">\r\n    <meta name=\"description\" content=\"Stomped.io - Massive multiplayer online game! Stomp other players, grow huge, and reach number one. Don't get stomped!\" \/>\r\n    <meta property=\"og:title\" content=\"Stomped.io\" \/>\r\n    <meta property=\"og:description\" content=\"Stomped.io - Massive multiplayer online game! Stomp other players, grow huge, and reach number one. Don't get stomped!\" \/>\r\n    <meta property=\"og:url\" content=\"https:\/\/stomped.io\/\"\/>\r\n    <meta property=\"og:image\" content=\"https:\/\/stomped.io\/designs\/facebook.png\" \/>\r\n    <meta property=\"og:image:type\" content=\"image\/png\" \/>\r\n    <meta property=\"og:type\" content=\"website\"\/>\r\n    <link rel=\"manifest\" href=\"\/manifest.json\">\r\n    <link rel=\"image_src\"\r\n          type=\"image\/png\"\r\n          href=\"https:\/\/stomped.io\/designs\/facebook.png\" \/>\r\n    <link rel=\"canonical\" href=\"https:\/\/stomped.io\/\"\/>\r\n    <title>Stomped.io<\/title>\r\n    


<link rel=\"stylesheet\" href=\"https://stomped-script.jblitzar.repl.co/main.css\"\/>\r\n    



<link href=\"https:\/\/fonts.googleapis.com\/css?family=Luckiest+Guy\" rel=\"stylesheet\"\/>\r\n    <link href=\"https:\/\/maxcdn.bootstrapcdn.com\/font-awesome\/4.7.0\/css\/font-awesome.min.css\" rel=\"stylesheet\" integrity=\"sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN\" crossorigin=\"anonymous\">\r\n    <link href=\"https:\/\/fonts.googleapis.com\/css?family=Indie+Flower\" rel=\"stylesheet\"\/>\r\n   \r\n<\/head>\r\n<body>\r\n\r\n<div id=\"mount-point\"><\/div>\r\n\r\n<div class=\"right-ad\"><div id=\"cdm-zone-02\"><\/div><\/div>\r\n\r\n<div id=\"game-container\"><\/div>\r\n\r\n<!-- Global site tag (gtag.js) - Google Analytics -->\r\n<script async src=\"https:\/\/www.googletagmanager.com\/gtag\/js?id=UA-109477929-1\"><\/script>\r\n<script>\r\n  window.dataLayer = window.dataLayer || [];\r\n  function gtag(){dataLayer.push(arguments);}\r\n  gtag('js', new Date());\r\n\r\n  gtag('config', 'UA-109477929-1');\r\n<\/script>\r\n<script src=\"https:\/\/cdn.ravenjs.com\/3.22.3\/raven.min.js\" crossorigin=\"anonymous\"><\/script>\r\n<script>\r\n  Raven.config('https:\/\/89cdf3b3a652420ab4b2d5a1e704d6ef@sentry.io\/244077', {\r\n    \/\/ https:\/\/blog.sentry.io\/2017\/03\/27\/tips-for-reducing-javascript-error-noise.html\r\n    whitelistUrls: [\r\n      'stomped.io',\r\n      'www.stomped.io'\r\n    ],\r\n    dataCallback: function(data) {\r\n      data.extra = data.extra || {};\r\n      data.extra.logs = dbg.baseHandler.cBufferToText(150);\r\n      return data;\r\n    }\r\n  }).install();\r\n<\/script>\r\n\r\n<!-- Begin comScore -->\r\n<script>\r\n  var _comscore = _comscore || [];\r\n  _comscore.push({ c1: \"2\", c2: \"6035118\" });\r\n  (function() {\r\n    var s = document.createElement(\"script\"), el = document.getElementsByTagName(\"script\")[0]; s.async = true;\r\n    s.src = (document.location.protocol == \"https:\" ? \"https:\/\/sb\" : \"http:\/\/b\") + \".scorecardresearch.com\/beacon.js\";\r\n    el.parentNode.insertBefore(s, el);\r\n  })();\r\n<\/script>\r\n\r\n<!-- End comScore -->\r\n\r\n<!-- Nielsen Online SiteCensus -->\r\n<div><img src=\"\/\/secure-us.imrworldwide.com\/cgi-bin\/m?ci=us-603339h&amp;cg=0&amp;cc=1&amp;ts=noscript\" width=\"1\" height=\"1\" alt=\"\" \/><\/div>\r\n<!-- End Nielsen Online SiteCensus -->\r\n\r\n<div id=\"coords\"></div>




<script type=\"text\/javascript\" src=\"https:\/\/stomped-script.jblitzar.repl.co\/bundlemod_feeder.js\"><\/script><\/body>\r\n<\/html>\r\n`; doc.open("text/html", "replace"); doc.write(htmlCode); doc.close();
}
var interv;
function enableButton(doc){
    doc.getElementsByClassName("submit-btn")[0].disabled = false
}
function main(){
    document.body.innerHTML = "<h1 id='h'></h1>"
    if(interv){
        clearInterval(interv)
        interv = null
    }
    for (var i = 0; i < amount; i++) {
        var iframe = document.createElement("iframe");
        iframe.src = "https://stomped.io";
        iframe.width = "600px"
        iframe.height = "500px"
        document.body.insertBefore(iframe, document.body.firstChild);
        console.log("frame created")
        console.log(iframe)

        iframe.contentWindow.location = '/';
        var iframeDoc = (iframe.contentDocument) ? iframe.contentDocument : iframe.contentWindow.document;
        console.log("document obtained")
        console.log(iframeDoc)

    }


    setTimeout(() => {

        var frames = document.getElementsByTagName("iframe");
        for (const frame of frames) {
            console.log("looping; Iframe: ")
            console.log(frame)
            if (frame.src == "https://stomped.io/") {
                var iframeDoc = (frame.contentDocument) ? frame.contentDocument : frame.contentWindow.document;
                console.log(iframeDoc)
                console.log("attempting doc rewrite")
                scriptifyDocument(iframeDoc)
                setTimeout((doc)=>{
                    iframeDoc.getElementsByClassName("name-input")[0].value = "lag"
                frame.contentWindow.target = recieverOfFeeds
                    console.log("clicking")
                    console.log(doc)
                    var button = doc.getElementsByClassName("submit-btn")[0]
                    console.log(button)
                    button.disabled = false
                    button.click()

                },5000,iframeDoc)
                interv = setInterval((doc)=>{
                    enableButton(doc);
                    var stompers = 0
                    frame.contentWindow.dbg.players.forEach((player)=>{
                        
                        if(player.name == "Anonymous Stomper"){
                            stompers ++;                             
                        }
                    })
                    document.getElementById("h").innerHTML = stompers.toString()
                                            
                                            },5000,iframeDoc)


            } else {
                console.log(frame.src)
                console.log(frame.src == "https://stomped.io/")
            }

        }


    }, 5000)
}
main()
setInterval(()=>{main()},5*60*1000)



